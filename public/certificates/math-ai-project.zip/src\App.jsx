import MathSolverComponent from './components/MathSolverComponent';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-950 flex items-start justify-center p-4 sm:p-8">
      <MathSolverComponent />
    </div>
  );
}
