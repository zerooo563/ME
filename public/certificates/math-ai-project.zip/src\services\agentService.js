const API_KEY = import.meta.env.VITE_GEMINI_API_KEY;

if (!API_KEY) {
  console.warn(
    "⚠️  VITE_GEMINI_API_KEY is not set. Add it to your .env file:\n   VITE_GEMINI_API_KEY=AIza..."
  );
}

const API_BASE = "https://generativelanguage.googleapis.com/v1beta";

const AGENTS = {
  solver: {
    model: "gemini-2.5-flash",
    systemPrompt: `أنت محلل رياضي كبير. مهمتك هي حل المعادلة الرياضية خطوة بخطوة.

تعليمات صارمة:
- اكتب الشرح بالإنجليزية.
- استخدم LaTeX لجميع الرموز الرياضية: $...$ للصيغ المضمنة و $$...$$ للصيغ المستقلة.
- ابدأ بعنوان "## الحل الأكاديمي" ثم اكتب الحل.
- اشرح كل خطوة جبرية ومنطقية بالتفصيل.
- تأكد من أن الحل صحيح 100% وخالٍ من الأخطاء.
- في النهاية، اكتب الحل النهائي بصيغة واضحة.`,
  },
  critic: {
    model: "gemini-2.5-flash",
    systemPrompt: `أنت خبير مراجعة وضمان جودة رياضي. مهمتك هي تدقيق حل المعادلة المقدم من المحلل الأول.

تعليمات صارمة:
- اكتب المراجعة بالإنجليزية.
- ابدأ بعنوان "## مراجعة الناقد".
- استخدم هذا التنسيق بدقة:
  - **الحالة**: (صحيح / يحتاج تحسين / خاطئ)
  - **الأخطاء**: (قائمة الأخطاء الجبرية أو المنطقية إن وجدت)
  - **الحالات الحدية**: (حالات خاصة أو قيود لم يتم مراعاتها)
  - **الاقتراحات**: (تحسينات مقترحة)
- استخدم LaTeX للرموز الرياضية.
- كن موضوعياً ودقيقاً.`,
  },
  judge: {
    model: "gemini-2.5-flash",
    systemPrompt: `أنت قاضٍ رياضي أعلى. مهمتك هي التركيب بين المعادلة الأصلية والحل الأول ومراجعة الناقد لإنتاج الحل النهائي المعصوم من الأخطاء.

تعليمات صارمة:
- اكتب الحل النهائي بالإنجليزية.
- ابدأ بعنوان "## الحكم النهائي".
- حل أي تناقضات بين المحلل والناقد.
- استخدم LaTeX لجميع الرموز الرياضية: $...$ و $$...$$.
- قدم الحل النهائي الصحيح والمتكامل مع شرح وافٍ.
- تأكد من أن الناتج هو الحل المطلق الصحيح.`,
  },
  visualizer: {
    model: "gemini-2.5-flash",
    systemPrompt: `أنت خبير في الرسوم البيانية. مهمتك هي تحويل خطوات الحل الرياضي النهائي إلى رسم بياني باستخدام Mermaid.js.

تعليمات صارمة جداً:
- اخرج ONLY كود Mermaid الخام.
- استخدم graph TD للتخطيط من الأعلى إلى الأسفل.
- استخدم [] للمربعات و {} للقرارات إن وجدت.
- لا تكتب أي كلمات خارج كود mermaid.
- لا تكتب أي شرح أو مقدمة.
- ابدأ مباشرة بـ 'graph TD' وأنهِ بدون أي نص إضافي.`,
  },
  explainer: {
    model: "gemini-2.5-flash",
    systemPrompt: `أنت أستاذ رياضيات وخبير في التبسيط التربوي. مهمتك هي شرح الحل النهائي للمعادلة بطريقة مبسطة لطالب يعاني من صعوبة في الفهم.

تعليمات صارمة:
- اكتب الشرح بالإنجليزية.
- ابدأ بعنوان "## شرح مبسط".
- استخدم تشبيهات من الحياة اليومية لتبسيط المفاهيم.
- اشرح لماذا تعمل كل خطوة، ليس فقط كيف.
- استخدم لغة بسيطة وخالية من المصطلحات المعقدة.
- أضف سؤالاً تفاعلياً واحداً في النهاية بعنوان "💡 هل تعلم؟" لتعزيز الفهم.
- لا تستخدم LaTeX إلا للضرورة القصوى.`,
  },
};

async function callAgent(agentKey, prompt, signal) {
  const config = AGENTS[agentKey];

  const augmentedPrompt = `${config.systemPrompt}\n\n---\n\n${prompt}`;

  const url = `${API_BASE}/models/${config.model}:generateContent?key=${API_KEY}`;

  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: augmentedPrompt }] }],
      generationConfig: {
        temperature: 0.4,
        maxOutputTokens: 4096,
      },
    }),
    signal,
  });

  if (!response.ok) {
    let errorMsg;
    try {
      const err = await response.json();
      errorMsg = err.error?.message || err.error?.status || response.statusText;
    } catch {
      errorMsg = `HTTP ${response.status}: ${response.statusText}`;
    }
    throw new Error(errorMsg);
  }

  const data = await response.json();
  return data.candidates?.[0]?.content?.parts?.[0]?.text || "";
}

function withTimeout(promise, ms) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`⏱️ تجاوز timeout بعد ${ms / 1000} ثواني`)), ms);
  });
  return Promise.race([promise.finally(() => clearTimeout(timer)), timeout]);
}

const AGENT_TIMEOUT = 45000;
const PIPELINE_TIMEOUT = 180000;

function extractMermaidCode(text) {
  const match = text.match(/```mermaid\s*([\s\S]*?)```/);
  if (match) return match[1].trim();
  const lines = text.split("\n");
  const mermaidStart = lines.findIndex(
    (l) => l.trim().startsWith("graph ") || l.trim().startsWith("flowchart ")
  );
  if (mermaidStart !== -1) {
    return lines.slice(mermaidStart).join("\n").trim();
  }
  return text.trim();
}

/**
 * Solves a mathematical equation through a 5-agent sequential pipeline.
 *
 * Pipeline: Solver → Critic → Judge → (Visualizer + Explainer concurrently)
 *
 * @param {string} equation - The mathematical equation to solve.
 * @param {function} [onProgress] - Optional callback(agentKey) for UI status updates.
 * @returns {Promise<object>} { equation, finalSolution, mermaidCode, simpleExplanation, meta }
 */
export async function solveEquationPipeline(equation, onProgress) {
  if (!equation || equation.trim().length === 0) {
    throw new Error("❌ يرجى إدخال معادلة رياضية لحلها.");
  }

  if (!API_KEY) {
    throw new Error(
      '❌ لم يتم تعيين مفتاح Gemini API. الرجاء إضافته إلى ملف .env:\n   VITE_GEMINI_API_KEY=AIza...'
    );
  }

  const meta = {};

  const STEP_NAMES = ["solver", "critic", "judge", "visualizer", "explainer"];
  const STEP_LABELS = { solver: "المحلل", critic: "الناقد", judge: "القاضي", visualizer: "المرئي", explainer: "الشارح" };
  let currentStep = "";

  try {
    // ─── Step 1: Solver ───────────────────────────────────────────────
    currentStep = "solver";
    onProgress?.("solver");
    const solverResult = await withTimeout(callAgent("solver",
      `Solve the following equation step by step with explanation:\n\n${equation}`), AGENT_TIMEOUT);
    meta.solverOutput = solverResult;

    // ─── Step 2: Critic ───────────────────────────────────────────────
    currentStep = "critic";
    onProgress?.("critic");
    const criticResult = await withTimeout(callAgent("critic",
      `Original equation:\n${equation}\n\nSolution from analyst:\n${solverResult}\n\nReview this solution and evaluate it.`), AGENT_TIMEOUT);
    meta.criticOutput = criticResult;

    // ─── Step 3: Judge ────────────────────────────────────────────────
    currentStep = "judge";
    onProgress?.("judge");
    const judgeResult = await withTimeout(callAgent("judge",
      `Original equation:\n${equation}\n\nAnalyst solution:\n${solverResult}\n\nCritic review:\n${criticResult}\n\nSynthesize the correct final solution.`), AGENT_TIMEOUT);

    // ─── Step 4 & 5: Visualizer + Explainer (concurrent) ─────────────
    currentStep = "visualizer";
    onProgress?.("visualizer");

    currentStep = "explainer";
    onProgress?.("explainer");

    const [visualizerRaw, explainerResult] = await Promise.all([
      withTimeout(callAgent("visualizer",
        `Convert the following solution steps into a Mermaid flowchart:\n\n${judgeResult}`), AGENT_TIMEOUT),
      withTimeout(callAgent("explainer",
        `Explain the following solution in simple, easy-to-understand terms:\n\n${judgeResult}`), AGENT_TIMEOUT),
    ]);

    const mermaidCode = extractMermaidCode(visualizerRaw);

    return {
      equation,
      finalSolution: judgeResult,
      mermaidCode,
      simpleExplanation: explainerResult,
      meta,
    };
  } catch (err) {
    console.error("❌ Pipeline error at step:", currentStep, err);
    const label = STEP_LABELS[currentStep] || "المعالجة";
    const fullMsg = err.message || String(err);
    const isQuota = fullMsg.includes("429") || fullMsg.includes("quota") || fullMsg.includes("Quota");
    const isModel = fullMsg.includes("404") || fullMsg.includes("not found") || fullMsg.includes("not supported");
    let hint = "";
    if (isQuota) hint = "\n\n💡 الحل: انتظر دقيقة وحاول مرة أخرى، أو استخدم مفتاح API بحدود استخدام أعلى.";
    else if (isModel) hint = "\n\n💡 الموديل غير متاح. تأكد من اسم الموديل في الإعدادات.";
    throw new Error(`فشلت خطوة "${label}": ${fullMsg}${hint}`);
  }
}
