import { useState, useRef, useEffect, useCallback } from "react";
import ReactMarkdown from "react-markdown";
import remarkMath from "remark-math";
import rehypeKatex from "rehype-katex";
import "katex/dist/katex.min.css";
import mermaid from "mermaid";
import { Brain } from "lucide-react";
import { PromptInputBox } from "@/components/ui/ai-prompt-box";
import { solveEquationPipeline } from "../services/agentService";

// ─── Agent configuration for the status UI timeline ─────────────────────
const AGENT_STEPS = [
  { key: "solver",    label: "Solver",          subtitle: "Senior Mathematical Analyst",  icon: "\uD83E\uDDE0", color: "cyan"    },
  { key: "critic",    label: "Critic",          subtitle: "Peer Reviewer & QA Expert",    icon: "\uD83D\uDD0D", color: "amber"   },
  { key: "judge",     label: "Judge",           subtitle: "Supreme Mathematical Judge",   icon: "\u2696\uFE0F", color: "violet"  },
  { key: "visualizer",label: "Visualizer",      subtitle: "Data Visualization Expert",    icon: "\uD83C\uDFA8", color: "emerald" },
  { key: "explainer", label: "Explainer",       subtitle: "Pedagogy Expert",              icon: "\uD83D\uDCD6", color: "pink"    },
];

const COLOR_STYLES = {
  cyan:    { dot: "bg-cyan-400",    ring: "ring-cyan-400/50",  glow: "shadow-cyan-500/20",  line: "bg-cyan-500/30" },
  amber:   { dot: "bg-amber-400",   ring: "ring-amber-400/50", glow: "shadow-amber-500/20", line: "bg-amber-500/30" },
  violet:  { dot: "bg-violet-400",  ring: "ring-violet-400/50",glow: "shadow-violet-500/20",line: "bg-violet-500/30" },
  emerald: { dot: "bg-emerald-400", ring: "ring-emerald-400/50",glow:"shadow-emerald-500/20",line:"bg-emerald-500/30" },
  pink:    { dot: "bg-pink-400",    ring: "ring-pink-400/50",  glow: "shadow-pink-500/20",  line: "bg-pink-500/30" },
};

// ─── Sub-component: animated status timeline ──────────────────────────
function AgentStatusTimeline({ activeAgent, completedAgents }) {
  return (
    <div className="flex flex-col gap-2 py-2">
      {AGENT_STEPS.map((step, i) => {
        const isActive = activeAgent === step.key;
        const isDone = completedAgents.includes(step.key);
        const cs = COLOR_STYLES[step.color];

        return (
          <div key={step.key} className="flex items-start gap-3">
            {/* Dot + connector */}
            <div className="flex flex-col items-center">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all duration-500 ring-2
                  ${isDone ? `${cs.dot} ring-white/30 scale-100` : ""}
                  ${isActive ? `${cs.dot} ${cs.ring} scale-110 ${cs.glow} animate-pulse` : ""}
                  ${!isActive && !isDone ? "bg-gray-700 ring-gray-600" : ""}
                `}
              >
                {isDone ? (
                  <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                  </svg>
                ) : isActive ? (
                  <span className="animate-bounce text-sm">{step.icon}</span>
                ) : (
                  <span className="text-gray-400 text-xs">{i + 1}</span>
                )}
              </div>
              {i < AGENT_STEPS.length - 1 && (
                <div className={`w-0.5 h-8 ${isDone ? cs.line : "bg-gray-700"}`} />
              )}
            </div>

            {/* Label */}
            <div className="pt-1">
              <p className={`text-sm font-medium transition-colors duration-300 ${
                isDone ? "text-white" : isActive ? "text-white" : "text-gray-500"
              }`}>
                {isActive && <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse mr-1.5" />}
                {step.label}
              </p>
              <p className={`text-[10px] transition-colors duration-300 ${
                isDone || isActive ? "text-gray-400" : "text-gray-600"
              }`}>
                {step.subtitle}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── Sub-component: renders a Mermaid.js diagram string ──────────────
function MermaidDiagram({ chart }) {
  const ref = useRef(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    if (!chart || !ref.current) return;
    let mounted = true;

    const render = async () => {
      try {
        mermaid.initialize({
          startOnLoad: false,
          theme: "dark",
          themeVariables: {
            background: "transparent",
            primaryColor: "#1e1b4b",
            primaryTextColor: "#e2e8f0",
            primaryBorderColor: "#6366f1",
            lineColor: "#818cf8",
            secondaryColor: "#0f172a",
            tertiaryColor: "#1e293b",
          },
        });
        if (!mounted) return;
        ref.current.innerHTML = chart;
        await mermaid.run({ nodes: [ref.current] });
      } catch {
        if (mounted) setError(true);
      }
    };
    render();
    return () => { mounted = false; };
  }, [chart]);

  if (error) {
    return (
      <pre className="text-gray-400 text-xs whitespace-pre-wrap font-mono bg-gray-900/50 rounded-lg p-4 overflow-x-auto">
        {chart}
      </pre>
    );
  }
  return <div ref={ref} className="mermaid w-full overflow-x-auto py-2 flex justify-center" />;
}

// ─── Sub-component: Markdown renderer with LaTeX support ─────────────
function MarkdownLatex({ content }) {
  return (
    <ReactMarkdown
      remarkPlugins={[remarkMath]}
      rehypePlugins={[rehypeKatex]}
      components={{
        // Render code blocks (including mermaid) as pre
        code({ node, inline, className, children, ...props }) {
          if (!inline && className === "language-mermaid") {
            return <MermaidDiagram chart={String(children)} />;
          }
          return (
            <code
              className={`${className || ""} text-cyan-300 bg-gray-800/60 px-1 rounded text-xs`}
              {...props}
            >
              {children}
            </code>
          );
        },
        pre({ children }) {
          return <pre className="bg-gray-900/60 rounded-lg p-4 overflow-x-auto text-sm leading-relaxed">{children}</pre>;
        },
        // Style headings
        h2({ children }) {
          return <h2 className="text-lg font-bold text-white mt-6 mb-3 pb-1 border-b border-white/5">{children}</h2>;
        },
        h3({ children }) {
          return <h3 className="text-base font-semibold text-gray-200 mt-4 mb-2">{children}</h3>;
        },
        p({ children }) {
          return <p className="text-gray-300 text-sm leading-relaxed mb-3">{children}</p>;
        },
        ul({ children }) {
          return <ul className="list-disc list-inside text-gray-300 text-sm space-y-1 mb-3">{children}</ul>;
        },
        strong({ children }) {
          return <strong className="text-gray-100 font-semibold">{children}</strong>;
        },
        em({ children }) {
          return <em className="text-gray-400">{children}</em>;
        },
      }}
    >
      {content}
    </ReactMarkdown>
  );
}

// ─── Main component ──────────────────────────────────────────────────
export default function MathSolverComponent() {
  const [equation, setEquation] = useState("");
  const [resetKey, setResetKey] = useState(0);
  const [pipelineState, setPipelineState] = useState("idle"); // idle | running | success | error
  const [activeAgent, setActiveAgent] = useState(null);
  const [completedAgents, setCompletedAgents] = useState([]);
  const [results, setResults] = useState(null);
  const [error, setError] = useState("");

  const agentOrder = AGENT_STEPS.map((s) => s.key);
  const pipelineRef = useRef(null);

  // ── Handles the Solve click ────────────────────────────────────────
  const handleSolve = useCallback(async (eq) => {
    const equationText = (eq || equation).trim();
    if (!equationText) {
      setError("Please enter a mathematical equation to solve.");
      return;
    }
    setEquation(equationText);

    // Reset state
    setPipelineState("running");
    setActiveAgent(null);
    setCompletedAgents([]);
    setResults(null);
    setError("");

    // onProgress is called by the pipeline when each agent starts
    const onProgress = (agentKey) => {
      const idx = agentOrder.indexOf(agentKey);
      setActiveAgent(agentKey);
      if (idx > 0) {
        setCompletedAgents(agentOrder.slice(0, idx));
      }
    };

    try {
      const output = await solveEquationPipeline(equationText, onProgress);
      if (pipelineRef.current === "cancelled") return;
      setResults(output);
      setCompletedAgents(agentOrder); // mark all complete
      setActiveAgent(null);
      setPipelineState("success");
    } catch (err) {
      if (pipelineRef.current === "cancelled") return;
      setError(err.message || "An unknown error occurred.");
      setPipelineState("error");
    }
  }, [agentOrder]);

  // ── Render ───────────────────────────
  return (
    <div className="w-full max-w-5xl mx-auto">
      <div className="bg-gradient-to-br from-gray-900 via-slate-900 to-gray-950 rounded-2xl border border-white/5 shadow-2xl overflow-hidden">
        <div className="p-6 sm:p-8">
          {/* ── Header ──────────────────────────────────────────────── */}
            <div className="flex items-center gap-4 mb-6">
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-cyan-500 to-violet-600 flex items-center justify-center shadow-lg">
                <Brain className="w-6 h-6 text-white" />
              </div>
            <div>
              <h1 className="text-xl font-bold text-white">Multi-Agent Math Solver</h1>
              <p className="text-xs text-gray-500">
                5-agent pipeline &middot; Gemini 2.5 Flash
              </p>
            </div>
          </div>

          {/* ── Input area (AI Prompt Box) ──────────────────────────── */}
          <PromptInputBox
            key={resetKey}
            onSend={(message) => handleSolve(message)}
            isLoading={pipelineState === "running"}
            placeholder="e.g., x^2 - 5x + 6 = 0, or integral of sin(x) from 0 to pi"
          />

          {/* ── Pipeline status (visible while running) ────────────── */}
          {pipelineState === "running" && (
            <div
              className="mt-5 bg-gray-800/20 backdrop-blur-sm rounded-xl border border-white/5 p-4"
              style={{ animation: "fadeSlideIn 0.3s ease-out" }}
            >
              <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">
                \u2699 Pipeline Progress
              </p>
              <AgentStatusTimeline activeAgent={activeAgent} completedAgents={completedAgents} />
            </div>
          )}

          {/* ── Error banner ───────────────────────────────────────── */}
          {pipelineState === "error" && error && (
            <div
              className="mt-5 bg-red-500/10 border border-red-500/30 rounded-xl p-4 flex items-start gap-3"
              style={{ animation: "fadeSlideIn 0.3s ease-out" }}
            >
              <svg className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <div className="flex-1">
                <p className="text-sm text-red-300 font-medium">Pipeline Error</p>
                <p className="text-xs text-red-400/80 mt-1">{error}</p>
              </div>
              <button onClick={() => setPipelineState("idle")} className="text-red-400/50 hover:text-red-300">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          )}

          {/* ── Results ────────────────────────────────────────────── */}
          {results && (
            <div className="mt-6 space-y-6">
              {/* ── Academic Solution (Judge output) ───────────────── */}
              <div
                className="bg-gray-800/40 backdrop-blur-xl rounded-xl border border-white/5 p-5 shadow-lg"
                style={{ animation: "fadeSlideIn 0.4s ease-out" }}
              >
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-lg">\uD83D\uDCD6</span>
                  <h3 className="text-base font-bold text-white">Academic Solution</h3>
                  <span className="ml-auto text-[10px] px-2 py-0.5 rounded-full bg-violet-500/20 text-violet-300">
                    Judge Agent
                  </span>
                </div>
                <div className="prose prose-invert max-w-none">
                  <MarkdownLatex content={results.finalSolution} />
                </div>
              </div>

              {/* ── Simplified Explanation (Explainer) ─────────────── */}
              <div
                className="bg-gray-800/40 backdrop-blur-xl rounded-xl border border-white/5 p-5 shadow-lg"
                style={{ animation: "fadeSlideIn 0.5s ease-out" }}
              >
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-lg">\uD83D\uDCD6</span>
                  <h3 className="text-base font-bold text-white">Simplified Explanation</h3>
                  <span className="ml-auto text-[10px] px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-300">
                    Explainer Agent
                  </span>
                </div>
                <div className="text-gray-300 text-sm leading-relaxed whitespace-pre-wrap">
                  <MarkdownLatex content={results.simpleExplanation} />
                </div>
              </div>

              {/* ── Visual Flowchart (Visualizer) ──────────────────── */}
              {results.mermaidCode && (
                <div
                  className="bg-gray-800/40 backdrop-blur-xl rounded-xl border border-white/5 p-5 shadow-lg"
                  style={{ animation: "fadeSlideIn 0.6s ease-out" }}
                >
                  <div className="flex items-center gap-2 mb-4">
                    <span className="text-lg">\uD83C\uDFA8</span>
                    <h3 className="text-base font-bold text-white">Visual Flowchart</h3>
                    <span className="ml-auto text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300">
                      Visualizer Agent
                    </span>
                  </div>
                  <div className="bg-gray-900/40 rounded-lg p-4 flex justify-center overflow-x-auto">
                    <MermaidDiagram chart={results.mermaidCode} />
                  </div>
                </div>
              )}

              {/* ── Raw solver / critic (expandable) ───────────────── */}
              {results.meta && (
                <details className="group">
                  <summary className="text-xs text-gray-500 cursor-pointer hover:text-gray-300 transition-colors select-none">
                    \u25B6 Agent details (Solver + Critic raw outputs)
                  </summary>
                  <div className="mt-3 space-y-3">
                    {results.meta.solverOutput && (
                      <div className="bg-gray-800/20 rounded-lg p-4 border border-white/5">
                        <p className="text-xs font-semibold text-cyan-400 mb-2">\uD83E\uDDE0 Solver Output</p>
                        <pre className="text-gray-400 text-xs whitespace-pre-wrap font-mono max-h-60 overflow-y-auto">
                          {results.meta.solverOutput}
                        </pre>
                      </div>
                    )}
                    {results.meta.criticOutput && (
                      <div className="bg-gray-800/20 rounded-lg p-4 border border-white/5">
                        <p className="text-xs font-semibold text-amber-400 mb-2">\uD83D\uDD0D Critic Output</p>
                        <pre className="text-gray-400 text-xs whitespace-pre-wrap font-mono max-h-60 overflow-y-auto">
                          {results.meta.criticOutput}
                        </pre>
                      </div>
                    )}
                  </div>
                </details>
              )}

              {/* ── New Equation button ────────────────────────────── */}
              <div className="flex justify-center pt-2">
                <button
                  onClick={() => {
                    setEquation("");
                    setResults(null);
                    setPipelineState("idle");
                    setError("");
                    setResetKey((k) => k + 1);
                  }}
                  className="px-5 py-2 text-xs font-medium text-gray-400 hover:text-white bg-gray-800/60 hover:bg-gray-700/60 rounded-lg transition-colors border border-white/5"
                >
                  \u21A9 Solve New Equation
                </button>
              </div>
            </div>
          )}

          {/* ── Empty state ─────────────────────────────────────────── */}
          {pipelineState === "idle" && !error && (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-gray-800 to-gray-700 flex items-center justify-center mb-4 border border-white/5">
                <Brain className="w-8 h-8 text-gray-400" />
              </div>
              <p className="text-gray-400 font-medium text-lg">Enter an equation to solve</p>
              <p className="text-gray-600 text-sm mt-1 max-w-md">
                The system routes your equation through 5 specialized AI agents:
                Solver \u2192 Critic \u2192 Judge \u2192 Visualizer \u2192 Explainer
              </p>
              <div className="flex flex-wrap gap-2 mt-4 justify-center">
                {AGENT_STEPS.map((s) => (
                  <span key={s.key} className="text-xs px-2.5 py-1 rounded-full bg-gray-800/60 text-gray-400 border border-white/5">
                    {s.icon} {s.label}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ── Footer credit ──────────────────────────────────────────── */}
      <div className="text-center mt-6 pt-4 border-t border-white/5">
        <p className="text-xs text-gray-500 max-w-xl mx-auto leading-relaxed">
          Multi-agent math solver — 5 specialized AI agents (Solver, Critic, Judge, Visualizer, Explainer)
          work in sequence to solve, verify, visualize, and explain mathematical equations.
        </p>
        <p className="text-[11px] text-gray-600 mt-2">
          Produced by <span className="text-gray-400">Abd Alrahman Abd Albaqi</span> — Mathematics Graduate
        </p>
      </div>

      {/* ── Keyframe animations ────────────────────────────────────── */}
      <style>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(10px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
